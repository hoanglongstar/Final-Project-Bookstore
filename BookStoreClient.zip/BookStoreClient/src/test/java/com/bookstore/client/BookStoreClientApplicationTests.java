package com.bookstore.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
