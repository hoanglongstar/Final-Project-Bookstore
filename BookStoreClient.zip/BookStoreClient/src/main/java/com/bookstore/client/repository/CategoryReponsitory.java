package com.bookstore.client.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookstore.model.entities.Category;

public interface CategoryReponsitory extends JpaRepository<Category, Integer> {
	
	
}
