package com.bookstore.client.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bookstore.client.services.ProductService;
import com.bookstore.model.entities.Product;

public class ProductController {

	@Autowired
	private ProductService productService;
//	@Autowired
//	private CategoryService categoryService;
	
	@RequestMapping(value = {"/productlist"})
	public String showProductView(Model model) {	
		
		List<Product> products = productService.getAllProduct();
		model.addAttribute("products", products);
		return showProductPageView(model, 1);
		

	}
	
	@RequestMapping(value = {"/productlist/{pageNum}"})
	public String showProductPageView(Model model, @PathVariable(name = "pageNum") int pageNum) {
		
		Page<Product> pageProduct = productService.getProductsWithPage(pageNum);
		List<Product> products = pageProduct.getContent();
		
		long startCount = (pageNum - 1) * ProductService.PAGE_SIZE + 1;
		long endCount = startCount + ProductService.PAGE_SIZE - 1;
		
		if( endCount > pageProduct.getTotalElements()) {
			endCount = pageProduct.getTotalElements();
		}
		
		model.addAttribute("products", products);
		model.addAttribute("totalPages", pageProduct.getTotalPages());
		model.addAttribute("totalProducts", pageProduct.getTotalElements());
		model.addAttribute("currentPage", pageNum);
		model.addAttribute("startCount", startCount);
		model.addAttribute("endCount", endCount);
		
		return "product-list";
	}
}
